
f = open("file.txt", "r")
if f.mode == "r":
    content = f.read()

# print(content)

# if any capital letter is found in ff.txt then it will be considered as a small alphabet
# if any other special character is found then it is ignored including spaces and numbers

each_char = [0]*26
count = 0

for i in content:
    if i.isalpha():
        count += 1
        i = i.lower()
        i = ord(i) % 97
        each_char[i] += 1

# final = {}
# final = each_char/count
# print(final)
for j in range(26):
    each_char[j] = each_char[j]*1.0/count

print(each_char)
